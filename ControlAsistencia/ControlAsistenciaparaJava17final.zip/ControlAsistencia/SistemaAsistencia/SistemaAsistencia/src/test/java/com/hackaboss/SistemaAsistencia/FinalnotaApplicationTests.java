package com.hackaboss.SistemaAsistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalnotaApplicationTests {

	@Test
	void contextLoads() {
	}

}
